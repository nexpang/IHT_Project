const SocketState={
    IN_LOGIN:0,
    IN_LOBBY:1,
    IN_ROOM:2,
    IN_PLAYING:3
}

module.exports = SocketState;